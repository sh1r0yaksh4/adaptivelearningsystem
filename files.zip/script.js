// Configuration
const API_URL = 'http://localhost:4000';

// Sample questions
const questions = {
    easy: [
        { id: 1, text: 'What is 2 + 2?', options: ['3', '4', '5', '6'], correct: 1 },
        { id: 2, text: 'What is the capital of France?', options: ['London', 'Berlin', 'Paris', 'Madrid'], correct: 2 },
        { id: 3, text: 'What color is the sky?', options: ['Green', 'Blue', 'Red', 'Yellow'], correct: 1 },
        { id: 4, text: 'How many days in a week?', options: ['5', '6', '7', '8'], correct: 2 },
        { id: 5, text: 'What is 5 × 3?', options: ['10', '15', '20', '25'], correct: 1 }
    ],
    medium: [
        { id: 6, text: 'What is the square root of 144?', options: ['10', '11', '12', '13'], correct: 2 },
        { id: 7, text: 'Who wrote Romeo and Juliet?', options: ['Marlowe', 'Shakespeare', 'Jonson', 'Bacon'], correct: 1 },
        { id: 8, text: 'What is the atomic number of Carbon?', options: ['4', '6', '8', '12'], correct: 1 },
        { id: 9, text: 'In what year did WWII end?', options: ['1943', '1944', '1945', '1946'], correct: 2 },
        { id: 10, text: 'What is 15% of 200?', options: ['20', '25', '30', '35'], correct: 2 }
    ],
    hard: [
        { id: 11, text: 'What is the derivative of x³?', options: ['x²', '2x²', '3x²', '3x'], correct: 2 },
        { id: 12, text: 'Which philosopher wrote Critique of Pure Reason?', options: ['Hegel', 'Kant', 'Nietzsche', 'Schopenhauer'], correct: 1 },
        { id: 13, text: 'What is Avogadro\'s number?', options: ['6.02 × 10²³', '3.14 × 10²³', '2.71 × 10²³', '9.81 × 10²³'], correct: 0 },
        { id: 14, text: 'What does GDP stand for?', options: ['Gross Domestic Product', 'Global Development Plan', 'Government Debt Program', 'General Data Protocol'], correct: 0 },
        { id: 15, text: 'What is the limit of sin(x)/x as x approaches 0?', options: ['0', '1', 'undefined', 'infinity'], correct: 1 }
    ]
};

// Global state
let appState = {
    userName: '',
    stats: {
        totalQuestions: 0,
        correctAnswers: 0,
        currentDifficulty: 'medium',
        accuracy: 0
    },
    quiz: {
        currentDifficulty: 'medium',
        currentQuestionIndex: 0,
        selectedAnswer: null,
        isAnswered: false,
        startTime: null,
        nextDifficulty: null
    }
};

// Page Management
function showPage(pageName) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(pageName).classList.add('active');
}

// Login Handler
function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('username').value.trim();
    
    if (username) {
        appState.userName = username;
        document.getElementById('display-name').textContent = username;
        updateDashboard();
        showPage('dashboard-page');
    }
}

// Logout
function logout() {
    appState.userName = '';
    appState.stats = {
        totalQuestions: 0,
        correctAnswers: 0,
        currentDifficulty: 'medium',
        accuracy: 0
    };
    document.getElementById('username').value = '';
    showPage('login-page');
}

// Update Dashboard
function updateDashboard() {
    document.getElementById('total-questions').textContent = appState.stats.totalQuestions;
    document.getElementById('correct-answers').textContent = appState.stats.correctAnswers;
    document.getElementById('accuracy').textContent = appState.stats.accuracy + '%';
    document.getElementById('current-level').textContent = appState.stats.currentDifficulty.toUpperCase();
}

// Start Quiz
function startQuiz() {
    appState.quiz = {
        currentDifficulty: appState.stats.currentDifficulty,
        currentQuestionIndex: 0,
        selectedAnswer: null,
        isAnswered: false,
        startTime: Date.now(),
        nextDifficulty: null
    };
    
    loadQuestion();
    showPage('quiz-page');
}

// Load Question
function loadQuestion() {
    const currentQuestions = questions[appState.quiz.currentDifficulty];
    const currentQuestion = currentQuestions[appState.quiz.currentQuestionIndex];
    
    if (!currentQuestion) {
        backToDashboard();
        return;
    }
    
    // Update question number
    document.getElementById('question-number').textContent = appState.quiz.currentQuestionIndex + 1;
    document.getElementById('quiz-level').textContent = appState.quiz.currentDifficulty.toUpperCase();
    
    // Load question text
    document.getElementById('question-text').textContent = currentQuestion.text;
    
    // Load options
    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';
    
    currentQuestion.options.forEach((option, index) => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'option';
        optionDiv.textContent = option;
        optionDiv.onclick = () => selectOption(index);
        optionDiv.id = `option-${index}`;
        optionsContainer.appendChild(optionDiv);
    });
    
    // Reset state
    appState.quiz.selectedAnswer = null;
    appState.quiz.isAnswered = false;
    appState.quiz.nextDifficulty = null;
    
    // Reset UI
    document.getElementById('result-box').style.display = 'none';
    document.getElementById('submit-btn').style.display = 'block';
    document.getElementById('next-btn').style.display = 'none';
}

// Select Option
function selectOption(index) {
    if (appState.quiz.isAnswered) return;
    
    appState.quiz.selectedAnswer = index;
    
    document.querySelectorAll('.option').forEach((opt, i) => {
        opt.classList.toggle('selected', i === index);
    });
}

// Submit Answer
async function submitAnswer() {
    if (appState.quiz.selectedAnswer === null) {
        alert('Please select an answer');
        return;
    }
    
    const currentQuestions = questions[appState.quiz.currentDifficulty];
    const currentQuestion = currentQuestions[appState.quiz.currentQuestionIndex];
    const isCorrect = appState.quiz.selectedAnswer === currentQuestion.correct;
    const timeTaken = Math.round((Date.now() - appState.quiz.startTime) / 1000);
    
    // Update stats
    appState.stats.totalQuestions++;
    if (isCorrect) {
        appState.stats.correctAnswers++;
    }
    appState.stats.accuracy = Math.round((appState.stats.correctAnswers / appState.stats.totalQuestions) * 100);
    
    // Call ML service
    try {
        const response = await fetch(`${API_URL}/question/submit`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                isCorrect: isCorrect,
                timeTaken: timeTaken,
                attempts: appState.stats.totalQuestions,
                pastAccuracy: appState.stats.accuracy / 100
            })
        });
        
        const result = await response.json();
        appState.quiz.nextDifficulty = result.nextDifficulty || appState.stats.currentDifficulty;
        appState.stats.currentDifficulty = appState.quiz.nextDifficulty;
        
    } catch (error) {
        console.error('Error calling ML service:', error);
        appState.quiz.nextDifficulty = appState.stats.currentDifficulty;
    }
    
    // Show result
    showResult(isCorrect, currentQuestion.correct, timeTaken);
    appState.quiz.isAnswered = true;
}

// Show Result
function showResult(isCorrect, correctIndex, timeTaken) {
    const resultBox = document.getElementById('result-box');
    const resultMessage = document.getElementById('result-message');
    const nextDifficultyMsg = document.getElementById('next-difficulty');
    
    // Highlight correct/incorrect
    document.querySelectorAll('.option').forEach((opt, i) => {
        opt.classList.remove('selected');
        if (i === correctIndex) {
            opt.classList.add('correct');
        }
        if (i === appState.quiz.selectedAnswer && i !== correctIndex) {
            opt.classList.add('incorrect');
        }
        opt.classList.add('disabled');
    });
    
    // Show result message
    resultMessage.textContent = isCorrect ? '✓ Correct!' : '✗ Incorrect';
    resultMessage.style.color = isCorrect ? '#28a745' : '#dc3545';
    nextDifficultyMsg.textContent = `Time: ${timeTaken}s | Next Level: ${appState.quiz.nextDifficulty.toUpperCase()}`;
    
    resultBox.style.display = 'block';
    document.getElementById('submit-btn').style.display = 'none';
    document.getElementById('next-btn').style.display = 'block';
}

// Next Question
function nextQuestion() {
    const currentQuestions = questions[appState.quiz.currentDifficulty];
    
    if (appState.quiz.currentQuestionIndex < currentQuestions.length - 1) {
        appState.quiz.currentQuestionIndex++;
        appState.quiz.startTime = Date.now();
        loadQuestion();
    } else {
        backToDashboard();
    }
}

// Back to Dashboard
function backToDashboard() {
    updateDashboard();
    showPage('dashboard-page');
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    showPage('login-page');
});
